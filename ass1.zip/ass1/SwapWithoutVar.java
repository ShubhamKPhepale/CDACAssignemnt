package com.excercise1;

import java.util.Scanner;

public class SwapWithoutVar {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter value of x");
		int x = sc.nextInt();
		System.out.println("Enter value of x");
		int y = sc.nextInt();
		
		x=x+y;
		y=x-y;
		x=x-y;
		
		System.out.println("value of a after swap "+x);
		
		System.out.println("value of b after swap "+y);

	}

}

package com.excercise1;

import java.util.Scanner;

public class ReverseString {
	
	
	 public static String reverse(String str) {
		    if (str.isEmpty())
		      return str;

		    return reverse(str.substring(1)) + str.charAt(0);
		  }

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string :");
		String str = sc.nextLine();
		    String rev = reverse(str);
		    System.out.println("The reversed string is: " + rev);
	}

}
